export function transformToNumber(value) {
  return +value;
}

