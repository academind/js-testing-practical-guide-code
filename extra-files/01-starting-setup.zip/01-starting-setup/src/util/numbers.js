export function transformToNumber(value) {
  // return NaN;
  return +value;
}

