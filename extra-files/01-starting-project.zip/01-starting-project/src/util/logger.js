export default function log(message) {
  console.log(message);
}
